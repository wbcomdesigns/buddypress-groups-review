<?php // phpcs:ignore WordPress.Files.FileName.InvalidClassFileName -- Legacy file name.
/**
 * BGR Group Review rating.
 *
 * @since   1.0.0
 * @author  Wbcom Designs
 *
 * @package    BuddyPress_Group_Review
 * @subpackage BuddyPress_Group_Review/includes/widgets
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

// phpcs:disable Universal.Files.SeparateFunctionsFromOO.Mixed -- Legacy widget registration.

/**
 * BGR Group Review rating.
 *
 * @since   1.0.0
 * @author  Wbcom Designs
 *
 * @package    BuddyPress_Group_Review
 * @subpackage BuddyPress_Group_Review/includes/widgets
 */
class Bgr_Single_Group_Rating_Widget extends WP_Widget {

	/**
	 * Constructor.
	 *
	 * @since 1.0.0
	 */
	public function __construct() {
		$widget_ops  = array(
			'classname'   => 'widget_bp_group_review_tab buddypress',
			'description' => esc_html__( 'Display displayed group ratings.', 'bp-group-reviews' ),
		);
		$control_ops = array(
			'width'  => 200,
			'height' => 350,
		);
		parent::__construct( 'bgr_group_rating_widget', esc_html__( 'BP Displayed Group Rating Widget', 'bp-group-reviews' ), $widget_ops, $control_ops );
	}

	/**
	 * Form display for widget in admin panel.
	 *
	 * @since 1.0.0
	 * @param array $instance Instance.
	 */
	public function form( $instance ) {
		if ( empty( $instance ) ) {
			$instance = wp_parse_args(
				(array) $instance,
				array(
					'widget_title'   => '',
					'post_num'       => '5',
					'rating_default' => 'latest',
				)
			);
		}
		// phpcs:ignore WordPress.PHP.DontExtract.extract_extract -- Legacy widget code.
		extract( $instance );
		$rating_default = esc_attr( $instance['rating_default'] );
		?>
		<div class="bgr_review_listing_form">
			<p>
				<label for="<?php echo esc_attr( $this->get_field_id( 'widget_title' ) ); ?>"><?php esc_html_e( 'Title', 'bp-group-reviews' ); ?>:</label>
				<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'widget_title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'widget_title' ) ); ?>" type="text" value="<?php echo esc_attr( $widget_title ); ?>" />
			</p>
			<p>
				<label for="<?php echo esc_attr( $this->get_field_id( 'post_num' ) ); ?>"><?php esc_html_e( 'Number of reviews to show', 'bp-group-reviews' ); ?>:
					<input id="<?php echo esc_attr( $this->get_field_id( 'post_num' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'post_num' ) ); ?>" type="number" min="1" step="1" value="<?php echo esc_attr( $post_num ); ?>" />
				</label>
			</p>
			<p>
				<label for="<?php echo esc_attr( $this->get_field_id( 'rating_default' ) ); ?>"><?php esc_html_e( 'Default ratings to show:', 'bp-group-reviews' ); ?></label>
				<select name="<?php echo esc_attr( $this->get_field_name( 'rating_default' ) ); ?>" id="<?php echo esc_attr( $this->get_field_id( 'rating_default' ) ); ?>">
					<option value="latest" <?php selected( $rating_default, 'latest' ); ?>><?php esc_html_e( 'Latest', 'bp-group-reviews' ); ?></option>
					<option value="highest" <?php selected( $rating_default, 'highest' ); ?>><?php esc_html_e( 'Highest', 'bp-group-reviews' ); ?></option>
					<option value="lowest"  <?php selected( $rating_default, 'lowest' ); ?>><?php esc_html_e( 'Lowest', 'bp-group-reviews' ); ?></option>
				</select>
			</p>
		</div><!-- .bgr_review_listing_form -->
		<?php
	}

	/**
	 * Update Widget data.
	 *
	 * @since 1.0.0
	 * @param array $new_instance New Instance.
	 * @param array $old_instance Old Instance.
	 * @return array Updated instance.
	 */
	public function update( $new_instance, $old_instance ) {
		$instance                   = $old_instance;
		$instance['widget_title']   = wp_strip_all_tags( $new_instance['widget_title'] );
		$instance['post_num']       = $new_instance['post_num'];
		$instance['rating_default'] = $new_instance['rating_default'];
		return $instance;
	}

	/**
	 * Display Widget content.
	 *
	 * @since 1.0.0
	 * @param array $args     Widget arguments.
	 * @param array $instance Instance.
	 */
	public function widget( $args, $instance ) {
		if ( ! bp_get_current_group_id() ) {
			return;
		}
		// phpcs:ignore WordPress.PHP.DontExtract.extract_extract -- Legacy widget code.
		extract( $instance, EXTR_SKIP );
		$widget_title          = apply_filters( 'widget_title', $widget_title );
		$widget_post_num       = max( 1, absint( apply_filters( 'post_num', $post_num ) ) );
		$widget_rating_default = apply_filters( 'rating_default', $rating_default );

		// Cached per-review rating index (review_id => average, newest first)
		// replaces the previous unbounded get_posts( -1 ) + N+1 meta scan.
		$stats          = bgr_get_group_review_stats( bp_get_current_group_id() );
		$single_rev_avg = array_filter( $stats['index'] );

		if ( 'highest' === $widget_rating_default ) {
			arsort( $single_rev_avg, SORT_NUMERIC );
		} elseif ( 'lowest' === $widget_rating_default ) {
			asort( $single_rev_avg, SORT_NUMERIC );
		}

		// Bound the working set to the widget's own display limit.
		$single_rev_avg = array_slice( $single_rev_avg, 0, $widget_post_num, true );

		$final_review_obj = array();
		if ( ! empty( $single_rev_avg ) ) {
			$review_posts = get_posts(
				array(
					'post_type'      => 'review',
					'post_status'    => 'publish',
					'posts_per_page' => count( $single_rev_avg ),
					'post__in'       => array_keys( $single_rev_avg ),
					'orderby'        => 'post__in',
				)
			);
			foreach ( $review_posts as $review_post ) {
				$final_review_obj[ $review_post->ID ] = $review_post;
			}
			// Drop index entries whose post no longer resolves.
			$single_rev_avg = array_intersect_key( $single_rev_avg, $final_review_obj );
		}
		echo wp_kses_post( $args['before_widget'] );
		if ( empty( $widget_title ) ) {
			$group      = groups_get_group( array( 'group_id' => bp_get_current_group_id() ) );
			$group_name = $group->name;
			/* translators: %s: Group name. */
			$widget_title = sprintf( __( "%s's Ratings", 'bp-group-reviews' ), $group_name );
		}
		echo wp_kses_post( $args['before_title'] . $widget_title . $args['after_title'] );

		$bgr_user_count = 0;
		if ( ! empty( $single_rev_avg ) ) {
			?>
			<div class="item-options" id="bp-group-rating-list-options">
				<a href="#" attr-val="latest" id="member_latest_reviews"
				<?php
				if ( 'latest' === $rating_default ) :
					?>
					class="selected"<?php endif; ?>><?php esc_html_e( 'Latest', 'bp-group-reviews' ); ?></a>
				| <a href="#" attr-val="highest" id="member_good_reviews"
				<?php
				if ( 'highest' === $rating_default ) :
					?>
					class="selected"<?php endif; ?>><?php esc_html_e( 'Highest', 'bp-group-reviews' ); ?></a>
				| <a href="#" attr-val="lowest" id="member_bad_reviews"
				<?php
				if ( 'lowest' === $rating_default ) :
					?>
					class="selected"<?php endif; ?>><?php esc_html_e( 'Lowest', 'bp-group-reviews' ); ?></a>
			</div>
			<?php
			echo '<ul class="item-list" id="bp-group-rating">';
			foreach ( $single_rev_avg as $bgr_key => $bgr_value ) {
				if ( (int) $bgr_user_count === (int) $widget_post_num ) {
					break;
				} else {
					echo '<li class="vcard"><div class="item-avatar">';
					echo get_avatar( $final_review_obj[ $bgr_key ]->post_author, 65 );
					echo '</div>';
					echo '<div class="item">';

					$members_profile = bp_core_get_userlink( $final_review_obj[ $bgr_key ]->post_author );
					echo '<div class="item-title fn">';
					echo wp_kses_post( $members_profile );
					echo '</div>';

					$bgr_avg_rating = $bgr_value;
					$stars_on       = 0;
					$stars_off      = 0;
					$stars_half     = 0;
					$remaining      = $bgr_avg_rating - (int) $bgr_avg_rating;
					if ( $remaining > 0 ) {
						$stars_on       = intval( $bgr_avg_rating );
						$stars_half     = 1;
						$bgr_half_squar = 1;
						$stars_off      = 5 - ( $stars_on + $stars_half );
					} else {
						$stars_on   = $bgr_avg_rating;
						$stars_off  = 5 - $bgr_avg_rating;
						$stars_half = 0;
					}
					echo '<div class="item-meta">';
					for ( $i = 1; $i <= $stars_on; $i++ ) {

						?>
					<span class="fas fa-star stars bgr-star-rate"></span>
						<?php
					}
					for ( $i = 1; $i <= $stars_half; $i++ ) {

						?>
					<span class="fas fa-star-half-alt stars bgr-star-rate"></span>
						<?php
					}
					for ( $i = 1; $i <= $stars_off; $i++ ) {

						?>
					<span class="far fa-star stars bgr-star-rate"></span>
						<?php
					}

					echo '</div>';

					$bgr_avg_rating = round( $bgr_avg_rating, 2 );
					echo '<span class="bgr-meta">';
					/* translators: %1$s: Average rating value. */
					printf( esc_html__( 'Rating : ( %1$s )', 'bp-group-reviews' ), esc_html( $bgr_avg_rating ) );
					echo '</span>';
					echo '</div></li>';

				}

				++$bgr_user_count;
			}
			echo '</ul>';
		} else {
			?>
			<div id="message" class="info">
			<?php
			esc_html_e( 'No ratings have been given by any members yet.', 'bp-group-reviews' );
			?>
			</div>
			<?php
		}
		?>
		<input type="hidden" value="<?php echo esc_attr( $widget_post_num ); ?>" class="group-rating-limit">
		<?php
		echo wp_kses_post( $args['after_widget'] );
	}
}

/**
 * Register Group Review Widget.
 *
 * @since 1.0.0
 */
function bp_group_review_register_rating_widget() {
	register_widget( 'Bgr_Single_Group_Rating_Widget' );
}

add_action( 'widgets_init', 'bp_group_review_register_rating_widget' );
